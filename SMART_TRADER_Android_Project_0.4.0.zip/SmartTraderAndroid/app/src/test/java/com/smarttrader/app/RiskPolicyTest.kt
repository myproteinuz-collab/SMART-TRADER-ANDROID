package com.smarttrader.app

import org.junit.Assert.assertEquals
import org.junit.Test

class RiskPolicyTest {
    @Test fun spotShortIsRejected() {
        val result = RiskPolicy.validate(TradeProposal("BTCUSDT", MarketType.SPOT, TradeSide.SHORT, 100.0, 105.0, 90.0))
        assertEquals(Decision.REJECTED, result.decision)
    }

    @Test fun missingStopLossIsRejected() {
        val result = RiskPolicy.validate(TradeProposal("BTCUSDT", MarketType.SPOT, TradeSide.LONG, 100.0, null, 120.0))
        assertEquals(Decision.REJECTED, result.decision)
    }

    @Test fun tooLowRewardRiskIsRejected() {
        val result = RiskPolicy.validate(TradeProposal("BTCUSDT", MarketType.SPOT, TradeSide.LONG, 100.0, 95.0, 105.0))
        assertEquals(Decision.REJECTED, result.decision)
    }

    @Test fun validPaperProposalPassesRiskValidation() {
        val result = RiskPolicy.validate(TradeProposal("BTCUSDT", MarketType.SPOT, TradeSide.LONG, 100.0, 95.0, 110.0))
        assertEquals(Decision.APPROVED_FOR_PAPER, result.decision)
    }
}
