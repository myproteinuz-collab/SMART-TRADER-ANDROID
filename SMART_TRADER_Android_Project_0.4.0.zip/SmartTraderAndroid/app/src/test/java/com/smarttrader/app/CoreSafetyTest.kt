package com.smarttrader.app

import org.junit.Assert.*
import org.junit.Test

class CoreSafetyTest {
    @Test fun paperSpotShortIsRejected() {
        val e = PaperTradingEngine()
        val r = e.open(PaperOrderRequest("BTCUSDT", MarketType.SPOT, TradeSide.SHORT, 100.0, 101.0, 98.0), "2026-11-09")
        assertFalse(r.accepted); assertEquals("SPOT_SHORT_FORBIDDEN", r.message)
    }

    @Test fun paperPositionClosesAtTakeProfit() {
        val e = PaperTradingEngine()
        assertTrue(e.open(PaperOrderRequest("BTCUSDT", MarketType.SPOT, TradeSide.LONG, 100.0, 99.0, 102.0), "2026-11-09").accepted)
        val trades = e.mark("BTCUSDT", 102.0)
        assertEquals(1, trades.size); assertEquals("TAKE_PROFIT", trades.single().reason)
        assertTrue(trades.single().netPnl > 0.0)
    }

    @Test fun paperPositionClosesAtStopLoss() {
        val e = PaperTradingEngine()
        assertTrue(e.open(PaperOrderRequest("ETHUSDT", MarketType.SPOT, TradeSide.LONG, 100.0, 99.0, 102.0), "2026-11-09").accepted)
        val trades = e.mark("ETHUSDT", 98.0)
        assertEquals("STOP_LOSS", trades.single().reason); assertTrue(trades.single().netPnl < 0.0)
    }

    @Test fun paperRejectsCrossAndLeverageAboveTwo() {
        val e = PaperTradingEngine()
        assertEquals("CROSS_MARGIN_FORBIDDEN", e.open(PaperOrderRequest("BTCUSDT", MarketType.FUTURES, TradeSide.LONG, 100.0, 99.0, 102.0, 2.0, false), "d1").message)
        assertEquals("LEVERAGE_LIMIT_EXCEEDED", e.open(PaperOrderRequest("BTCUSDT", MarketType.FUTURES, TradeSide.LONG, 100.0, 99.0, 102.0, 3.0, true), "d1").message)
    }

    @Test fun paperDailyLossLimitUsesEquityAndResetsNextDay() {
        val config = PaperConfig(feeRate = 0.0, slippageRate = 0.0, maxOpenRiskPct = 10.0, reservePct = 0.0)
        val engine = PaperTradingEngine(config)
        assertTrue(engine.open(PaperOrderRequest("BTCUSDT", MarketType.FUTURES, TradeSide.LONG, 100.0, 99.0, 102.0, 2.0, true), "d1").accepted)
        assertTrue(engine.open(PaperOrderRequest("ETHUSDT", MarketType.FUTURES, TradeSide.LONG, 100.0, 99.0, 102.0, 2.0, true), "d1").accepted)
        engine.mark("BTCUSDT", 99.0); engine.mark("ETHUSDT", 99.0)
        assertEquals("DAILY_LOSS_LIMIT", engine.open(PaperOrderRequest("SOLUSDT", MarketType.FUTURES, TradeSide.LONG, 100.0, 99.0, 102.0, 2.0, true), "d1").message)
        assertTrue(engine.open(PaperOrderRequest("SOLUSDT", MarketType.FUTURES, TradeSide.LONG, 100.0, 99.0, 102.0, 2.0, true), "d2").accepted)
    }

    @Test fun liveGateRequiresAllPreflightChecks() {
        val gate = LiveTradingGate()
        assertFalse(gate.arm(LivePreflight(false, true, true, true, true, true, true, true)))
        assertTrue(gate.arm(LivePreflight(true, true, true, true, true, true, true, true)))
    }

    @Test fun liveGateNeverRetriesUnknownOrderAutomatically() {
        val gate = LiveTradingGate()
        gate.arm(LivePreflight(true, true, true, true, true, true, true, true))
        assertTrue(gate.begin(LiveOrderIntent("oid-1", "BTC_USDT", 0.1), true, true))
        gate.onExchangeResult(ExchangeOrderState.UNKNOWN)
        assertEquals(LiveGateState.UNKNOWN_NEEDS_RECONCILIATION, gate.state)
        assertFalse(gate.begin(LiveOrderIntent("oid-2", "ETH_USDT", 0.1), true, true))
        assertFalse(gate.reconcile(ReconciliationState.UNKNOWN))
        assertTrue(gate.reconcile(ReconciliationState.DEFINITIVELY_NOT_FOUND))
    }

    @Test fun liveGateBlocksDuplicateClientOrderId() {
        val gate = LiveTradingGate()
        gate.arm(LivePreflight(true, true, true, true, true, true, true, true))
        val intent = LiveOrderIntent("same-id", "BTC_USDT", 0.1)
        assertTrue(gate.begin(intent, true, true)); gate.onExchangeResult(ExchangeOrderState.ACCEPTED)
        assertFalse(gate.begin(intent, true, true))
    }

    @Test fun futuresSizerUsesContractRulesAndTwoXLimit() {
        val spec = FuturesContractSpec("BTC_USDT", 0.0001, 1.0, 1000.0, 1.0, 1, 100, 50, 3, 0.1, 0.0001, true, 0)
        val r = FuturesOrderSizer.calculate(spec, 100000.0, 99000.0, 2, 10.0, 0.0)
        assertTrue(r.accepted); assertEquals(1.0, r.contracts, 0.0); assertTrue(r.estimatedRiskUsdt <= 0.20)
    }

    @Test fun futuresSizerRejectsNonApiContractAndCountryLeverage() {
        val notAllowed = FuturesContractSpec("BTC_USDT", .0001, 1.0, 1000.0, 1.0, 1, 100, 50, 3, .1, .0001, false, 0)
        assertEquals("CONTRACT_NOT_API_TRADABLE", FuturesOrderSizer.calculate(notAllowed, 100000.0, 99000.0, 2, 10.0, 0.0).reason)
        val countryLimited = notAllowed.copy(apiAllowed = true, countryMaxLeverage = 1)
        assertEquals("LEVERAGE_LIMIT_EXCEEDED", FuturesOrderSizer.calculate(countryLimited, 100000.0, 99000.0, 2, 10.0, 0.0).reason)
    }

    @Test fun futuresSignerReturnsDeterministicHmac() {
        val a = MexcFuturesSigner.signature("key", "secret", "1700000000000", "{\"symbol\":\"BTC_USDT\"}")
        val b = MexcFuturesSigner.signature("key", "secret", "1700000000000", "{\"symbol\":\"BTC_USDT\"}")
        assertEquals(a, b); assertTrue(a.matches(Regex("[0-9a-f]{64}")))
    }
}
