package com.smarttrader.app

import java.net.URLEncoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Signing rules for MEXC Futures OPEN-API, kept pure for deterministic tests. */
object MexcFuturesSigner {
    fun signature(accessKey: String, secret: String, timestamp: String, parameterString: String): String {
        require(accessKey.isNotBlank() && secret.isNotBlank() && timestamp.isNotBlank())
        val payload = accessKey + timestamp + parameterString
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    fun sortedQuery(parameters: Map<String, String>): String = parameters.toSortedMap()
        .entries.joinToString("&") { "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}" }
}
