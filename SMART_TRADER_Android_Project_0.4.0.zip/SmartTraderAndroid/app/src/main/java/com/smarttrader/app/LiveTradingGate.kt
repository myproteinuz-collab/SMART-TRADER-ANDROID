package com.smarttrader.app

/** Live execution state machine. It has no exchange/network implementation by design. */
enum class LiveGateState { DISABLED, ARMED, ORDER_IN_FLIGHT, UNKNOWN_NEEDS_RECONCILIATION, PAUSED }
enum class ExchangeOrderState { ACCEPTED, REJECTED, UNKNOWN }
enum class ReconciliationState { ORDER_FOUND, DEFINITIVELY_NOT_FOUND, UNKNOWN }

data class LivePreflight(
    val userConfirmedRealTrading: Boolean,
    val credentialsVerified: Boolean,
    val tradingPermissionVerified: Boolean,
    val accountStateFresh: Boolean,
    val symbolRulesVerified: Boolean,
    val clockSynchronized: Boolean,
    val riskChecksPassed: Boolean,
    val protectiveOrdersReady: Boolean,
    val killSwitchActive: Boolean = false
)

data class LiveOrderIntent(val clientId: String, val symbol: String, val riskUsdt: Double)

class LiveTradingGate(
    private val maxSingleRiskUsdt: Double = 0.20,
    private val maxTotalRiskUsdt: Double = 0.30
) {
    var state: LiveGateState = LiveGateState.DISABLED
        private set
    private val usedClientIds = mutableSetOf<String>()
    private var inFlight: LiveOrderIntent? = null
    private var openRiskUsdt: Double = 0.0

    @Synchronized
    fun arm(preflight: LivePreflight): Boolean {
        if (state == LiveGateState.UNKNOWN_NEEDS_RECONCILIATION || state == LiveGateState.ORDER_IN_FLIGHT) return false
        val ready = preflight.userConfirmedRealTrading && preflight.credentialsVerified &&
            preflight.tradingPermissionVerified && preflight.accountStateFresh &&
            preflight.symbolRulesVerified && preflight.clockSynchronized &&
            preflight.riskChecksPassed && preflight.protectiveOrdersReady && !preflight.killSwitchActive
        state = if (ready) LiveGateState.ARMED else LiveGateState.DISABLED
        return ready
    }

    /** Reserve intent ID before any network call. A retry with the same ID is always blocked. */
    @Synchronized
    fun begin(intent: LiveOrderIntent, accountRiskFresh: Boolean, riskPolicyPassed: Boolean): Boolean {
        if (state != LiveGateState.ARMED || inFlight != null) return false
        if (intent.clientId.isBlank() || intent.symbol.isBlank() || !intent.riskUsdt.isFinite() || intent.riskUsdt <= 0.0) return false
        if (intent.clientId in usedClientIds) return false
        if (!accountRiskFresh || !riskPolicyPassed) return false
        if (intent.riskUsdt > maxSingleRiskUsdt + 1e-9) return false
        if (openRiskUsdt + intent.riskUsdt > maxTotalRiskUsdt + 1e-9) return false
        usedClientIds += intent.clientId
        inFlight = intent
        state = LiveGateState.ORDER_IN_FLIGHT
        return true
    }

    @Synchronized
    fun onExchangeResult(result: ExchangeOrderState): Boolean {
        if (state != LiveGateState.ORDER_IN_FLIGHT || inFlight == null) return false
        when (result) {
            ExchangeOrderState.ACCEPTED -> {
                openRiskUsdt += inFlight!!.riskUsdt
                inFlight = null
                state = LiveGateState.ARMED
            }
            ExchangeOrderState.REJECTED -> {
                inFlight = null
                state = LiveGateState.ARMED
            }
            ExchangeOrderState.UNKNOWN -> state = LiveGateState.UNKNOWN_NEEDS_RECONCILIATION
        }
        return true
    }

    /** Only an authoritative exchange query may release an unknown order state. */
    @Synchronized
    fun reconcile(result: ReconciliationState): Boolean {
        if (state != LiveGateState.UNKNOWN_NEEDS_RECONCILIATION || inFlight == null) return false
        when (result) {
            ReconciliationState.ORDER_FOUND -> {
                openRiskUsdt += inFlight!!.riskUsdt
                inFlight = null
                state = LiveGateState.ARMED
            }
            ReconciliationState.DEFINITIVELY_NOT_FOUND -> {
                inFlight = null
                state = LiveGateState.ARMED
            }
            ReconciliationState.UNKNOWN -> return false
        }
        return true
    }

    @Synchronized
    fun reduceOpenRisk(amountUsdt: Double) {
        if (amountUsdt.isFinite() && amountUsdt > 0.0) openRiskUsdt = (openRiskUsdt - amountUsdt).coerceAtLeast(0.0)
    }

    @Synchronized
    fun killSwitch() {
        state = LiveGateState.PAUSED
    }

    @Synchronized
    fun disarm() {
        if (state != LiveGateState.UNKNOWN_NEEDS_RECONCILIATION && state != LiveGateState.ORDER_IN_FLIGHT) {
            state = LiveGateState.DISABLED
        }
    }

    @Synchronized
    fun currentOpenRiskUsdt(): Double = openRiskUsdt
}
