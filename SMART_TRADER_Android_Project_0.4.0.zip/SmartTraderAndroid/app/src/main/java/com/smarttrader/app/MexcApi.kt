package com.smarttrader.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object MexcApi {
    private const val BASE = "https://api.mexc.com"

    fun publicPrices(): Map<String, String> {
        val symbols = listOf("BTCUSDT", "ETHUSDT", "MXUSDT")
        val result = linkedMapOf<String, String>()
        symbols.forEach { symbol ->
            val json = get("$BASE/api/v3/ticker/price?symbol=$symbol")
            val price = JSONObject(json).optString("price", "")
            if (price.isNotBlank()) result[symbol] = "$" + String.format(java.util.Locale.US, "%,.2f", price.toDouble())
        }
        return result
    }

    /**
     * Read-only authenticated Spot account check.
     * Uses MEXC Spot V3 HMAC-SHA256 query signing.
     */
    fun checkSpotAccount(apiKey: String, secret: String): String {
        // Use exchange server time to avoid a rejected signature when the phone clock drifts.
        val serverTime = JSONObject(get("$BASE/api/v3/time")).optLong("serverTime", 0L)
        if (serverTime <= 0L) throw IllegalStateException("Не удалось получить время сервера MEXC")
        val timestamp = serverTime.toString()
        val query = "recvWindow=5000&timestamp=$timestamp"
        val signature = hmacSha256(secret, query)
        val url = "$BASE/api/v3/account?$query&signature=$signature"
        val raw = get(url, mapOf("X-MEXC-APIKEY" to apiKey))
        val json = JSONObject(raw)
        if (json.has("code")) {
            val code = json.optInt("code")
            val msg = json.optString("msg", "MEXC API error")
            throw IllegalStateException("MEXC $code: $msg")
        }
        val balances = json.optJSONArray("balances") ?: JSONArray()
        var usdt = 0.0
        for (i in 0 until balances.length()) {
            val item = balances.optJSONObject(i) ?: continue
            if (item.optString("asset") == "USDT") {
                usdt = item.optString("free", "0").toDoubleOrNull() ?: 0.0
                break
            }
        }
        return String.format(java.util.Locale.US, "%.4f USDT", usdt)
    }

    private fun get(url: String, headers: Map<String, String> = emptyMap()): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 12_000
            headers.forEach { (key, value) -> setRequestProperty(key, value) }
        }
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val detail = try {
                    val j = JSONObject(body)
                    "${j.opt("code")}: ${j.optString("msg", j.optString("message", body))}"
                } catch (_: Exception) { body.take(250) }
                throw IllegalStateException("HTTP $code — $detail")
            }
            body
        } finally {
            connection.disconnect()
        }
    }

    private fun hmacSha256(secret: String, payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(payload.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}
