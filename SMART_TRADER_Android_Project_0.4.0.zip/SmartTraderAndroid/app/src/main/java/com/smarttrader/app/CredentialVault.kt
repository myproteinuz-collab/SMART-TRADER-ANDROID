package com.smarttrader.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AES-256-GCM credential vault backed by Android Keystore.
 * Credentials are encrypted before SharedPreferences persistence.
 */
class CredentialVault(context: Context) {
    private val prefs = context.getSharedPreferences("st_private_vault", Context.MODE_PRIVATE)
    private val alias = "smart_trader_mexc_api_v1"

    @Synchronized
    fun save(apiKey: String, secret: String) {
        require(apiKey.isNotBlank() && secret.isNotBlank()) { "API Key и Secret Key обязательны" }
        val json = JSONObject().put("apiKey", apiKey).put("secret", secret).toString().toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(json)
        prefs.edit()
            .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("payload", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .apply()
        json.fill(0)
    }

    @Synchronized
    fun load(): Pair<String, String>? {
        val ivText = prefs.getString("iv", null) ?: return null
        val payloadText = prefs.getString("payload", null) ?: return null
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE, getOrCreateKey(),
            GCMParameterSpec(128, Base64.decode(ivText, Base64.NO_WRAP))
        )
        val plain = cipher.doFinal(Base64.decode(payloadText, Base64.NO_WRAP))
        return try {
            val json = JSONObject(String(plain, Charsets.UTF_8))
            json.getString("apiKey") to json.getString("secret")
        } finally {
            plain.fill(0)
        }
    }

    @Synchronized
    fun clear() {
        prefs.edit().clear().apply()
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(alias)) ks.deleteEntry(alias)
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}
