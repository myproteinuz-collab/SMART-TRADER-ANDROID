package com.smarttrader.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** MEXC Futures API client. Private calls use the current OPEN-API HMAC scheme. */
class MexcFuturesApi(private val apiKey: String, private val secret: String) {
    private val base = "https://api.mexc.com"

    init { require(apiKey.isNotBlank() && secret.isNotBlank()) }

    fun getServerTime(): Long = JSONObject(request("GET", "/api/v1/contract/ping")).optLong("data", 0L)
        .takeIf { it > 0L } ?: throw IOException("MEXC server time unavailable")

    fun getAccountAssets(): JSONArray = dataArray(signedGet("/api/v1/private/account/assets"))
    fun getOpenPositions(): JSONArray = dataArray(signedGet("/api/v1/private/position/open_positions"))

    fun getAvailableUsdt(): Double {
        val assets = getAccountAssets()
        for (i in 0 until assets.length()) {
            val asset = assets.optJSONObject(i) ?: continue
            if (asset.optString("currency").equals("USDT", ignoreCase = true))
                return asset.optDouble("availableBalance", Double.NaN).takeIf { it.isFinite() && it >= 0.0 }
                    ?: throw IOException("Invalid Futures USDT available balance")
        }
        return 0.0
    }

    /** Reconcile a timed-out order by its unique externalOid; never resubmits it. */
    fun reconcileExternalOrder(gate: LiveTradingGate, symbol: String, externalOid: String): JSONObject? {
        require(symbol.matches(Regex("[A-Z0-9]+_[A-Z0-9]+")))
        require(externalOid.isNotBlank() && externalOid.length <= 32)
        val json = JSONObject(signedGet("/api/v1/private/order/external/${encode(symbol)}/${encode(externalOid)}"))
        val data = json.optJSONObject("data")
        if (json.optBoolean("success", false) && data != null && data.optString("orderId").isNotBlank()) {
            check(gate.reconcile(ReconciliationState.ORDER_FOUND)) { "LIVE_GATE_NOT_WAITING_FOR_RECONCILIATION" }
            return data
        }
        if (json.optInt("code", -1) == 2040) {
            check(gate.reconcile(ReconciliationState.DEFINITIVELY_NOT_FOUND)) { "LIVE_GATE_NOT_WAITING_FOR_RECONCILIATION" }
            return null
        }
        gate.reconcile(ReconciliationState.UNKNOWN)
        throw IOException("Order state remains UNKNOWN; do not retry until exchange confirms status")
    }

    fun getPositionMode(): Int {
        val json = JSONObject(signedGet("/api/v1/private/position/position_mode"))
        requireSuccess(json)
        return json.optInt("data", 0).takeIf { it == 1 || it == 2 }
            ?: throw IOException("Unknown MEXC Futures position mode")
    }

    fun getContract(symbol: String): JSONObject {
        require(symbol.matches(Regex("[A-Z0-9]+_[A-Z0-9]+")))
        val json = JSONObject(request("GET", "/api/v1/contract/detail/country?symbol=${encode(symbol)}"))
        requireSuccess(json)
        return json.optJSONObject("data") ?: throw IOException("Contract metadata missing")
    }

    fun getContractSpec(symbol: String): FuturesContractSpec {
        val data = getContract(symbol)
        fun number(name: String) = data.optDouble(name, Double.NaN)
        return FuturesContractSpec(
            symbol = data.optString("symbol"),
            contractSize = number("contractSize"),
            minVol = number("minVol"),
            maxVol = number("maxVol"),
            volUnit = number("volUnit"),
            minLeverage = data.optInt("minLeverage", 0),
            maxLeverage = data.optInt("maxLeverage", 0),
            countryMaxLeverage = data.optInt("countryConfigContractMaxLeverage", 0),
            positionOpenType = data.optInt("positionOpenType", 0),
            priceUnit = number("priceUnit"),
            takerFeeRate = number("takerFeeRate"),
            apiAllowed = data.optBoolean("apiAllowed", false),
            state = data.optInt("state", -1)
        )
    }

    /**
     * Protected Futures entry. Caller must pass a fresh, validated size and an armed gate.
     * The exchange request includes SL and TP in the same create-order request.
     * Never retry automatically: a timeout is UNKNOWN and requires reconciliation.
     */
    fun placeProtectedMarketOrder(
        gate: LiveTradingGate,
        clientOrderId: String,
        symbol: String,
        side: TradeSide,
        leverage: Int,
        entryPrice: Double,
        stopLoss: Double,
        takeProfit: Double,
        size: FuturesSizeResult,
        positionMode: Int,
        accountRiskFresh: Boolean,
        riskPolicyPassed: Boolean
    ): String {
        require(symbol.matches(Regex("[A-Z0-9]+_[A-Z0-9]+")))
        require(size.accepted && size.reason == "SIZE_APPROVED" && size.contracts.isFinite() && size.contracts > 0.0)
        require(entryPrice.isFinite() && entryPrice > 0.0)
        require(stopLoss.isFinite() && stopLoss > 0.0 && takeProfit.isFinite() && takeProfit > 0.0)
        require(leverage in 1..2)
        require(positionMode == 1 || positionMode == 2)
        require(clientOrderId.length in 1..32)
        val proposalCheck = RiskPolicy.validate(TradeProposal(symbol, MarketType.FUTURES, side, entryPrice,
            stopLoss, takeProfit, leverage.toDouble(), isolatedMargin = true))
        check(proposalCheck.decision == Decision.APPROVED_FOR_PAPER) { "LIVE_RISK_POLICY_BLOCKED: ${proposalCheck.reasons.joinToString()}" }
        val intent = LiveOrderIntent(clientOrderId, symbol, size.estimatedRiskUsdt)
        val serverTimestamp = getServerTime().toString()
        val body = JSONObject()
            .put("symbol", symbol)
            .put("price", entryPrice)
            .put("vol", size.contracts)
            .put("leverage", leverage)
            .put("side", if (side == TradeSide.LONG) 1 else 3)
            .put("type", 5)
            .put("openType", 1)
            .put("externalOid", clientOrderId)
            .put("stopLossPrice", stopLoss)
            .put("takeProfitPrice", takeProfit)
            .put("lossTrend", 1)
            .put("profitTrend", 1)
            .put("positionMode", positionMode)
            .toString()
        val signature = MexcFuturesSigner.signature(apiKey, secret, serverTimestamp, body)
        check(gate.begin(intent, accountRiskFresh, riskPolicyPassed && size.accepted &&
            size.estimatedRiskUsdt > 0.0 && size.estimatedRiskUsdt <= 0.20)) { "LIVE_GATE_BLOCKED" }

        try {
            val response = request("POST", "/api/v1/private/order/create", body, mapOf(
                "ApiKey" to apiKey, "Request-Time" to serverTimestamp,
                "Signature" to signature, "Recv-Window" to "10000",
                "Content-Type" to "application/json", "Language" to "en-US"
            ))
            val json = JSONObject(response)
            if (json.optBoolean("success", false)) {
                val orderId = json.optJSONObject("data")?.optString("orderId").orEmpty()
                if (orderId.isNotBlank()) {
                    gate.onExchangeResult(ExchangeOrderState.ACCEPTED)
                    return orderId
                }
                gate.onExchangeResult(ExchangeOrderState.UNKNOWN)
                throw IOException("MEXC accepted response lacked an order ID; reconcile before retrying")
            }
            gate.onExchangeResult(ExchangeOrderState.REJECTED)
            throw IOException("MEXC rejected Futures order: ${json.optString("message", json.optString("msg", "unknown error"))}")
        } catch (e: ExchangeRejectedException) {
            if (gate.state == LiveGateState.ORDER_IN_FLIGHT) gate.onExchangeResult(ExchangeOrderState.REJECTED)
            throw e
        } catch (e: IOException) {
            if (gate.state == LiveGateState.ORDER_IN_FLIGHT) gate.onExchangeResult(ExchangeOrderState.UNKNOWN)
            throw e
        } catch (e: Exception) {
            if (gate.state == LiveGateState.ORDER_IN_FLIGHT) gate.onExchangeResult(ExchangeOrderState.UNKNOWN)
            throw IOException("Futures order result is UNKNOWN; reconcile before any retry", e)
        }
    }

    private fun signedGet(path: String): String {
        val timestamp = getServerTime().toString()
        val signature = MexcFuturesSigner.signature(apiKey, secret, timestamp, "")
        return request("GET", path, headers = mapOf(
            "ApiKey" to apiKey, "Request-Time" to timestamp,
            "Signature" to signature, "Recv-Window" to "10000"
        ))
    }

    private fun request(method: String, path: String, body: String? = null, headers: Map<String, String> = emptyMap()): String {
        val connection = URL(base + path).openConnection() as HttpURLConnection
        return try {
            connection.requestMethod = method
            connection.connectTimeout = 10_000
            connection.readTimeout = 10_000
            headers.forEach { (k, v) -> connection.setRequestProperty(k, v) }
            if (body != null) {
                connection.doOutput = true
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val payload = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                if (code >= 500) throw IOException("HTTP $code; operation status may be UNKNOWN")
                throw ExchangeRejectedException("HTTP $code: ${payload.take(300)}")
            }
            payload
        } finally { connection.disconnect() }
    }

    private fun dataArray(raw: String): JSONArray {
        val json = JSONObject(raw)
        requireSuccess(json)
        return json.optJSONArray("data") ?: JSONArray()
    }

    private fun requireSuccess(json: JSONObject) {
        if (!json.optBoolean("success", false) || json.optInt("code", 0) != 0)
            throw IOException("MEXC Futures API error ${json.opt("code")}: ${json.optString("message")}")
    }

    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
}

class ExchangeRejectedException(message: String) : IOException(message)

