package com.smarttrader.app

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Deterministic paper broker. It never sends network requests or exchange orders. */
data class PaperConfig(
    val startingCapitalUsdt: Double = 10.0,
    val feeRate: Double = 0.001,          // conservative estimate; configurable, not an exchange quote
    val slippageRate: Double = 0.0005,    // estimated adverse execution cost
    val targetRiskPct: Double = 1.0,
    val maxRiskPerTradePct: Double = 2.0,
    val maxOpenRiskPct: Double = 3.0,
    val maxDailyLossPct: Double = 2.0,
    val reservePct: Double = 10.0,
    val maxTradesPerDay: Int = 5,
    val minRewardRisk: Double = 1.5,
    val maxFuturesLeverage: Double = 2.0
)

data class PaperOrderRequest(
    val symbol: String,
    val market: MarketType,
    val side: TradeSide,
    val entry: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val leverage: Double = 1.0,
    val isolatedMargin: Boolean = true
)

data class PaperPosition(
    val id: Long,
    val symbol: String,
    val market: MarketType,
    val side: TradeSide,
    val entry: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val quantity: Double,
    val notional: Double,
    val margin: Double,
    val riskUsdt: Double,
    val entryFee: Double,
    val leverage: Double
)

data class PaperTrade(
    val position: PaperPosition,
    val exitPrice: Double,
    val grossPnl: Double,
    val exitFee: Double,
    val netPnl: Double,
    val reason: String
)

data class PaperResult(val accepted: Boolean, val message: String, val position: PaperPosition? = null)

data class PaperSnapshot(
    val cashUsdt: Double,
    val equityUsdt: Double,
    val openRiskUsdt: Double,
    val dailyPnlUsdt: Double,
    val tradesToday: Int,
    val openPositions: List<PaperPosition>,
    val closedTrades: List<PaperTrade>
)

class PaperTradingEngine(private val config: PaperConfig = PaperConfig()) {
    init {
        require(config.startingCapitalUsdt.isFinite() && config.startingCapitalUsdt > 0.0)
        require(config.feeRate.isFinite() && config.feeRate >= 0.0)
        require(config.slippageRate.isFinite() && config.slippageRate >= 0.0)
        require(config.targetRiskPct > 0.0 && config.maxRiskPerTradePct >= config.targetRiskPct)
        require(config.maxOpenRiskPct >= config.maxRiskPerTradePct && config.maxDailyLossPct > 0.0)
        require(config.reservePct in 0.0..90.0 && config.maxTradesPerDay > 0)
        require(config.minRewardRisk >= 1.0 && config.maxFuturesLeverage in 1.0..2.0)
    }
    private var cash = config.startingCapitalUsdt
    private var nextId = 1L
    private var dayKey: String? = null
    private var tradesToday = 0
    private var dailyStartEquity = config.startingCapitalUsdt
    private val open = linkedMapOf<Long, PaperPosition>()
    private val closed = mutableListOf<PaperTrade>()
    private val marks = mutableMapOf<String, Double>()

    @Synchronized
    fun open(request: PaperOrderRequest, day: String): PaperResult {
        rollDay(day)
        val invalid = validate(request)
        if (invalid != null) return PaperResult(false, invalid)
        if (tradesToday >= config.maxTradesPerDay) return PaperResult(false, "DAILY_TRADE_LIMIT")
        if (equityInternal() - dailyStartEquity <= -(config.startingCapitalUsdt * config.maxDailyLossPct / 100.0) + 1e-9)
            return PaperResult(false, "DAILY_LOSS_LIMIT")

        val riskBudget = config.startingCapitalUsdt * config.targetRiskPct / 100.0
        val stopDistancePct = abs(request.entry - request.stopLoss) / request.entry
        val stopDistance = abs(request.entry - request.stopLoss)
        val reserve = config.startingCapitalUsdt * config.reservePct / 100.0
        val availableCash = max(0.0, cash - reserve)
        val maxNotionalByCash = availableCash * request.leverage / (1.0 + config.feeRate)
        val quantityByRisk = riskBudget / stopDistance
        val quantityByCash = maxNotionalByCash / request.entry
        val quantity = min(quantityByRisk, quantityByCash)
        if (!quantity.isFinite() || quantity <= 0.0) return PaperResult(false, "INSUFFICIENT_AVAILABLE_MARGIN_AFTER_RESERVE")
        val notional = quantity * request.entry
        val margin = notional / request.leverage
        val entryFee = notional * config.feeRate
        val exitFeeEstimate = quantity * request.takeProfit * config.feeRate
        val rawStopRisk = quantity * stopDistance
        val riskWithCosts = rawStopRisk + entryFee + quantity * request.stopLoss * config.feeRate + notional * config.slippageRate * 2.0
        val maxRisk = config.startingCapitalUsdt * config.maxRiskPerTradePct / 100.0
        val totalRisk = open.values.sumOf { it.riskUsdt } + riskWithCosts
        val maxTotalRisk = config.startingCapitalUsdt * config.maxOpenRiskPct / 100.0
        if (riskWithCosts > maxRisk + 1e-9) return PaperResult(false, "RISK_PER_TRADE_LIMIT")
        if (totalRisk > maxTotalRisk + 1e-9) return PaperResult(false, "TOTAL_OPEN_RISK_LIMIT")
        if (margin + entryFee > cash - reserve + 1e-9) return PaperResult(false, "INSUFFICIENT_AVAILABLE_MARGIN_AFTER_RESERVE")
        if (!stopDistancePct.isFinite() || !exitFeeEstimate.isFinite()) return PaperResult(false, "INVALID_COST_ESTIMATE")

        val position = PaperPosition(nextId++, request.symbol.uppercase(), request.market, request.side,
            request.entry, request.stopLoss, request.takeProfit, quantity, notional, margin,
            riskWithCosts, entryFee, request.leverage)
        cash -= margin + entryFee
        open[position.id] = position
        marks[position.symbol] = request.entry
        tradesToday++
        return PaperResult(true, "PAPER_POSITION_OPENED", position)
    }

    /** Updates simulated mark prices and closes positions when SL or TP is crossed. */
    @Synchronized
    fun mark(symbol: String, price: Double): List<PaperTrade> {
        if (!price.isFinite() || price <= 0.0) return emptyList()
        val normalized = symbol.uppercase()
        marks[normalized] = price
        val triggered = open.values.filter { p ->
            p.symbol == normalized && when (p.side) {
                TradeSide.LONG -> price <= p.stopLoss || price >= p.takeProfit
                TradeSide.SHORT -> price >= p.stopLoss || price <= p.takeProfit
            }
        }
        return triggered.map { p ->
            val stopHit = when (p.side) {
                TradeSide.LONG -> price <= p.stopLoss
                TradeSide.SHORT -> price >= p.stopLoss
            }
            val trigger = if (stopHit) p.stopLoss else p.takeProfit
            val rawFill = when {
                stopHit && p.side == TradeSide.LONG -> min(price, trigger)
                stopHit && p.side == TradeSide.SHORT -> max(price, trigger)
                else -> trigger
            }
            val adverseFill = rawFill * if (p.side == TradeSide.LONG) (1.0 - config.slippageRate) else (1.0 + config.slippageRate)
            closeInternal(p, adverseFill, if (stopHit) "STOP_LOSS" else "TAKE_PROFIT")
        }
    }

    @Synchronized
    fun close(positionId: Long, exitPrice: Double, reason: String = "MANUAL"): PaperTrade? {
        if (!exitPrice.isFinite() || exitPrice <= 0.0) return null
        val p = open[positionId] ?: return null
        return closeInternal(p, exitPrice, reason)
    }

    @Synchronized
    fun snapshot(): PaperSnapshot {
        return PaperSnapshot(cash, equityInternal(), open.values.sumOf { it.riskUsdt },
            equityInternal() - dailyStartEquity, tradesToday, open.values.toList(), closed.toList())
    }

    private fun closeInternal(p: PaperPosition, exit: Double, reason: String): PaperTrade {
        val sign = if (p.side == TradeSide.LONG) 1.0 else -1.0
        val gross = (exit - p.entry) * p.quantity * sign
        val exitFee = exit * p.quantity * config.feeRate
        val net = gross - p.entryFee - exitFee
        cash += p.margin + gross - exitFee
        val trade = PaperTrade(p, exit, gross, exitFee, net, reason)
        open.remove(p.id)
        closed += trade
        return trade
    }

    private fun rollDay(day: String) {
        require(day.isNotBlank()) { "DAY_KEY_REQUIRED" }
        if (dayKey != day) {
            dayKey = day
            tradesToday = 0
            dailyStartEquity = equityInternal()
        }
    }

    private fun equityInternal(): Double {
        val usedMargin = open.values.sumOf { it.margin }
        val unrealized = open.values.sumOf { p ->
            val mark = marks[p.symbol] ?: p.entry
            (mark - p.entry) * p.quantity * if (p.side == TradeSide.LONG) 1.0 else -1.0
        }
        return cash + usedMargin + unrealized
    }

    private fun validate(r: PaperOrderRequest): String? {
        if (r.symbol.isBlank()) return "UNKNOWN_SYMBOL"
        if (!r.entry.isFinite() || r.entry <= 0.0 || !r.stopLoss.isFinite() || !r.takeProfit.isFinite()) return "INVALID_PRICE"
        if (r.market == MarketType.SPOT && r.side == TradeSide.SHORT) return "SPOT_SHORT_FORBIDDEN"
        if (r.market == MarketType.FUTURES && !r.isolatedMargin) return "CROSS_MARGIN_FORBIDDEN"
        if (r.market == MarketType.FUTURES && (r.leverage < 1.0 || r.leverage > config.maxFuturesLeverage)) return "LEVERAGE_LIMIT_EXCEEDED"
        if (r.market == MarketType.SPOT && r.leverage != 1.0) return "SPOT_LEVERAGE_FORBIDDEN"
        val directionOk = when (r.side) {
            TradeSide.LONG -> r.stopLoss < r.entry && r.takeProfit > r.entry
            TradeSide.SHORT -> r.stopLoss > r.entry && r.takeProfit < r.entry
        }
        if (!directionOk) return "INVALID_SL_TP_DIRECTION"
        val risk = abs(r.entry - r.stopLoss)
        val reward = abs(r.takeProfit - r.entry)
        if (risk <= 0.0 || reward / risk < config.minRewardRisk) return "REWARD_RISK_BELOW_MINIMUM"
        return null
    }
}
