package com.smarttrader.app

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Exchange metadata is fetched from MEXC GET /api/v1/contract/detail/country. */
data class FuturesContractSpec(
    val symbol: String,
    val contractSize: Double,
    val minVol: Double,
    val maxVol: Double,
    val volUnit: Double,
    val minLeverage: Int,
    val maxLeverage: Int,
    val countryMaxLeverage: Int,
    val positionOpenType: Int,
    val priceUnit: Double,
    val takerFeeRate: Double,
    val apiAllowed: Boolean,
    val state: Int
)

data class FuturesSizeResult(
    val accepted: Boolean,
    val reason: String,
    val contracts: Double = 0.0,
    val notionalUsdt: Double = 0.0,
    val marginUsdt: Double = 0.0,
    val estimatedRiskUsdt: Double = 0.0
)

object FuturesOrderSizer {
    fun calculate(
        spec: FuturesContractSpec,
        entry: Double,
        stopLoss: Double,
        leverage: Int,
        availableBalanceUsdt: Double,
        currentOpenRiskUsdt: Double,
        startingCapitalUsdt: Double = 10.0,
        targetRiskPct: Double = 1.0,
        maxRiskPerTradePct: Double = 2.0,
        maxOpenRiskPct: Double = 3.0,
        reservePct: Double = 10.0,
        slippageRate: Double = 0.0005
    ): FuturesSizeResult {
        if (spec.symbol.isBlank() || !entry.isFinite() || !stopLoss.isFinite() || entry <= 0.0 || stopLoss <= 0.0 ||
            !availableBalanceUsdt.isFinite() || availableBalanceUsdt < 0.0 ||
            !currentOpenRiskUsdt.isFinite() || currentOpenRiskUsdt < 0.0 ||
            !startingCapitalUsdt.isFinite() || startingCapitalUsdt <= 0.0 ||
            !slippageRate.isFinite() || slippageRate < 0.0)
            return FuturesSizeResult(false, "INVALID_MARKET_DATA")
        if (spec.apiAllowed.not() || spec.state != 0) return FuturesSizeResult(false, "CONTRACT_NOT_API_TRADABLE")
        if (spec.positionOpenType != 1 && spec.positionOpenType != 3) return FuturesSizeResult(false, "ISOLATED_MARGIN_NOT_SUPPORTED")
        if (!spec.contractSize.isFinite() || !spec.minVol.isFinite() || !spec.maxVol.isFinite() ||
            !spec.volUnit.isFinite() || !spec.priceUnit.isFinite() || !spec.takerFeeRate.isFinite() ||
            spec.contractSize <= 0 || spec.minVol <= 0 || spec.volUnit <= 0 || spec.maxVol < spec.minVol ||
            spec.priceUnit <= 0 || spec.takerFeeRate < 0)
            return FuturesSizeResult(false, "INVALID_CONTRACT_RULES")
        val effectiveMaxLeverage = if (spec.countryMaxLeverage > 0) min(spec.maxLeverage, spec.countryMaxLeverage) else spec.maxLeverage
        if (leverage < max(1, spec.minLeverage) || leverage > min(2, effectiveMaxLeverage))
            return FuturesSizeResult(false, "LEVERAGE_LIMIT_EXCEEDED")
        val stopDistance = absDiff(entry, stopLoss)
        if (stopDistance <= 0.0) return FuturesSizeResult(false, "INVALID_STOP_DISTANCE")
        if (!isAligned(entry, spec.priceUnit) || !isAligned(stopLoss, spec.priceUnit))
            return FuturesSizeResult(false, "PRICE_TICK_MISMATCH")
        val riskBudget = startingCapitalUsdt * targetRiskPct / 100.0
        val maxSingleRisk = startingCapitalUsdt * maxRiskPerTradePct / 100.0
        val maxTotalRisk = startingCapitalUsdt * maxOpenRiskPct / 100.0
        val perContractNotional = entry * spec.contractSize
        val perContractStopLoss = stopDistance * spec.contractSize
        val perContractFees = (entry + stopLoss) * spec.contractSize * spec.takerFeeRate
        val perContractSlippage = perContractNotional * slippageRate * 2.0
        val perContractRisk = perContractStopLoss + perContractFees + perContractSlippage
        if (!perContractRisk.isFinite() || perContractRisk <= 0.0) return FuturesSizeResult(false, "INVALID_RISK_ESTIMATE")
        val targetContracts = floor((riskBudget / perContractRisk) / spec.volUnit) * spec.volUnit
        val maxByBalanceNotional = max(0.0, availableBalanceUsdt - startingCapitalUsdt * reservePct / 100.0) * leverage / perContractNotional
        val affordableContracts = floor(maxByBalanceNotional / spec.volUnit) * spec.volUnit
        // If the exchange minimum lot slightly exceeds the 1% target, permit it only
        // when the complete estimated loss remains below the hard 2% per-trade cap.
        val riskSizedContracts = if (targetContracts < spec.minVol && perContractRisk * spec.minVol <= maxSingleRisk) spec.minVol else targetContracts
        val contracts = min(min(riskSizedContracts, affordableContracts), spec.maxVol)
        if (contracts + 1e-9 < spec.minVol) return FuturesSizeResult(false, "BELOW_EXCHANGE_MINIMUM_OR_RESERVE")
        val risk = contracts * perContractRisk
        if (risk > maxSingleRisk + 1e-9) return FuturesSizeResult(false, "RISK_PER_TRADE_LIMIT")
        if (currentOpenRiskUsdt + risk > maxTotalRisk + 1e-9) return FuturesSizeResult(false, "TOTAL_OPEN_RISK_LIMIT")
        val notional = contracts * perContractNotional
        val margin = notional / leverage
        if (margin + notional * spec.takerFeeRate > availableBalanceUsdt - startingCapitalUsdt * reservePct / 100.0 + 1e-9)
            return FuturesSizeResult(false, "INSUFFICIENT_MARGIN_AFTER_RESERVE")
        return FuturesSizeResult(true, "SIZE_APPROVED", contracts, notional, margin, risk)
    }

    private fun absDiff(a: Double, b: Double) = kotlin.math.abs(a - b)
    private fun isAligned(value: Double, step: Double): Boolean {
        val units = value / step
        return kotlin.math.abs(units - kotlin.math.round(units)) < 1e-7
    }
}
