package com.smarttrader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

private val Navy = Color(0xFF08111F)
private val Panel = Color(0xFF111E30)
private val Panel2 = Color(0xFF1B2A40)
private val Gold = Color(0xFFD8B56D)
private val Muted = Color(0xFF8FA1B8)
private val Green = Color(0xFF39C99A)
private val Red = Color(0xFFFF6B78)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vault = CredentialVault(applicationContext)
        setContent { SmartTraderApp(vault) }
    }
}

private enum class Tab(val label: String) {
    HOME("Главная"), MARKET("Рынок"), SCANNER("Сканер"), PORTFOLIO("Портфель"), API("MEXC"), SETTINGS("Настройки")
}

@Composable
private fun SmartTraderApp(vault: CredentialVault) {
    var selected by remember { mutableStateOf(Tab.HOME) }
    var mode by remember { mutableStateOf("PAPER") }
    var prices by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var marketStatus by remember { mutableStateOf("Загружаем котировки…") }
    var apiStatus by remember { mutableStateOf("API не подключён") }
    var spotBalance by remember { mutableStateOf("—") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        while (true) {
            try {
                val data = withContext(Dispatchers.IO) { MexcApi.publicPrices() }
                prices = data
                marketStatus = "Данные MEXC обновлены"
            } catch (e: Exception) {
                marketStatus = "Нет соединения: ${e.message ?: "ошибка сети"}"
            }
            kotlinx.coroutines.delay(15_000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Gold, secondary = Green,
        onBackground = Color.White, onSurface = Color.White, onPrimary = Navy
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    Tab.entries.forEach { tab ->
                        val icon = when (tab) {
                            Tab.HOME -> Icons.Default.Dashboard
                            Tab.MARKET -> Icons.Default.ShowChart
                            Tab.SCANNER -> Icons.Default.Radar
                            Tab.PORTFOLIO -> Icons.Default.AccountBalanceWallet
                            Tab.API -> Icons.Default.Key
                            Tab.SETTINGS -> Icons.Default.Settings
                        }
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Icon(icon, null) },
                            label = { Text(tab.label, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Panel2, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    Tab.HOME -> DashboardScreen(mode, prices, marketStatus, apiStatus, spotBalance) { selected = Tab.API }
                    Tab.MARKET -> MarketScreen(prices, marketStatus)
                    Tab.SCANNER -> ScannerScreen(prices)
                    Tab.PORTFOLIO -> PortfolioScreen()
                    Tab.API -> ApiScreen(
                        status = apiStatus, balance = spotBalance,
                        busy = busy, message = message,
                        onConnect = { key, secret ->
                            scope.launch {
                                busy = true
                                message = ""
                                try {
                                    val result = withContext(Dispatchers.IO) {
                                        MexcApi.checkSpotAccount(key.trim(), secret.trim())
                                    }
                                    withContext(Dispatchers.IO) { vault.save(key.trim(), secret.trim()) }
                                    apiStatus = "MEXC Spot подключён · подпись проверена"
                                    spotBalance = result
                                    message = "Подключение успешно. Ключи зашифрованы на устройстве."
                                } catch (e: Exception) {
                                    apiStatus = "Ошибка подключения"
                                    message = e.message ?: "MEXC не подтвердил запрос. Проверь права API и время устройства."
                                } finally {
                                    busy = false
                                }
                            }
                        },
                        onDelete = {
                            vault.clear()
                            apiStatus = "API не подключён"
                            spotBalance = "—"
                            message = "Сохранённые ключи удалены с устройства."
                        }
                    )
                    Tab.SETTINGS -> SettingsScreen(mode, onModeChange = { mode = it })
                }
            }
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
        Text("SMART TRADER", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun DashboardScreen(
    mode: String, prices: Map<String, String>, marketStatus: String,
    apiStatus: String, spotBalance: String, goApi: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item { Header("Обзор портфеля", "Личный торговый терминал") }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(19.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ТОРГОВЫЙ РЕЖИМ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.weight(1f))
                    Surface(color = if (mode == "PAPER") Color(0xFF183D37) else Color(0xFF49351D), shape = CircleShape) {
                        Text(if (mode == "PAPER") "PAPER" else "REAL · LOCKED", color = if (mode == "PAPER") Green else Gold,
                            fontSize = 9.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(if (mode == "PAPER") "10.00 USDT" else spotBalance, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text(if (mode == "PAPER") "Виртуальный стартовый капитал" else "Доступный баланс MEXC Spot", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(15.dp))
                HorizontalDivider(color = Panel2)
                Spacer(Modifier.height(12.dp))
                Row {
                    SmallMetric("Риск/сделка", "1%", Gold)
                    Spacer(Modifier.weight(1f))
                    SmallMetric("Дневной лимит", "2%", Red)
                    Spacer(Modifier.weight(1f))
                    SmallMetric("Сделок/день", "0 / 5", Green)
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("ПОДКЛЮЧЕНИЕ БИРЖИ", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(apiStatus, color = Color.White, fontSize = 13.sp)
                Text("Баланс: $spotBalance", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = goApi, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)) {
                    Text("Настроить MEXC")
                }
            }
        }
        item {
            SectionTitle("РЫНОК MEXC", marketStatus)
            PriceRow("BTC / USDT", prices["BTCUSDT"] ?: "—")
            PriceRow("ETH / USDT", prices["ETHUSDT"] ?: "—")
            PriceRow("MX / USDT", prices["MXUSDT"] ?: "—")
        }
        item {
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Text("ЗАЩИТА КАПИТАЛА", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(9.dp))
                RiskLine("Целевой риск на сделку", "1% · максимум 2%")
                RiskLine("Общий открытый риск", "3%")
                RiskLine("Дневной лимит убытка", "2%")
                RiskLine("Stop-Loss / Take-Profit", "Обязательны")
                RiskLine("Futures", "Изолированная маржа · до 2×")
            }
        }
        item { Text("Реальное исполнение ордеров в этой сборке заблокировано до завершения проверки торгового движка.", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun SmallMetric(label: String, value: String, color: Color) {
    Column {
        Text(label, color = Muted, fontSize = 9.sp)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.weight(1f))
        Text(subtitle, color = Muted, fontSize = 9.sp, maxLines = 1)
    }
    Spacer(Modifier.height(7.dp))
}

@Composable
private fun PriceRow(pair: String, price: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(pair, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        Text(price, color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
    HorizontalDivider(color = Panel2)
}

@Composable
private fun RiskLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MarketScreen(prices: Map<String, String>, status: String) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Spacer(Modifier.height(8.dp))
        Header("Рынок", "Публичные котировки MEXC · обновление 15 сек")
        CardPanel {
            Text(status, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            PriceRow("BTC / USDT", prices["BTCUSDT"] ?: "Загрузка…")
            PriceRow("ETH / USDT", prices["ETHUSDT"] ?: "Загрузка…")
            PriceRow("MX / USDT", prices["MXUSDT"] ?: "Загрузка…")
        }
    }
}

@Composable
private fun ScannerScreen(prices: Map<String, String>) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Spacer(Modifier.height(8.dp))
        Header("AI Scanner", "Первичный мониторинг рынка")
        CardPanel {
            Text("РЫНОЧНЫЕ ДАННЫЕ", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            PriceRow("BTC / USDT", prices["BTCUSDT"] ?: "—")
            PriceRow("ETH / USDT", prices["ETHUSDT"] ?: "—")
            Spacer(Modifier.height(14.dp))
            Text("Сканер торговых стратегий", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("В этой версии подключены живые цены. Генерация и автоматическое исполнение сигналов остаются отключёнными до проверки стратегии, комиссий, ликвидности и SL/TP.", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Text("СТАТУС: DATA FEED ACTIVE · STRATEGY ENGINE IN DEVELOPMENT", color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PortfolioScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Spacer(Modifier.height(8.dp))
        Header("Портфель", "Учёт Paper Trading")
        CardPanel {
            Text("10.00 USDT", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Text("Стартовый виртуальный баланс", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(15.dp))
            HorizontalDivider(color = Panel2)
            Spacer(Modifier.height(12.dp))
            Text("История сделок пока пуста", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("В следующем модуле добавим симулятор сделок, журнал и расчёт комиссий.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ApiScreen(
    status: String, balance: String, busy: Boolean, message: String,
    onConnect: (String, String) -> Unit, onDelete: () -> Unit
) {
    var key by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Spacer(Modifier.height(8.dp))
        Header("Подключение MEXC", "API credentials · хранение на устройстве")
        CardPanel {
            Text("СТАТУС", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(status, color = Color.White, fontSize = 13.sp)
            Text("Spot USDT баланс: $balance", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(14.dp))
            Text("ACCESS KEY", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = key, onValueChange = { key = it }, modifier = Modifier.fillMaxWidth(),
                singleLine = true, placeholder = { Text("Вставь MEXC API Key") },
                colors = apiFieldColors()
            )
            Spacer(Modifier.height(10.dp))
            Text("SECRET KEY", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = secret, onValueChange = { secret = it }, modifier = Modifier.fillMaxWidth(),
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                placeholder = { Text("Вставь MEXC Secret Key") }, colors = apiFieldColors()
            )
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { onConnect(key, secret) },
                enabled = key.isNotBlank() && secret.isNotBlank() && !busy,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy)
            ) { Text(if (busy) "Проверяем…" else "Сохранить и проверить MEXC") }
            OutlinedButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) { Text("Удалить сохранённые ключи") }
            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, color = if (message.contains("успешно")) Green else Gold, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        CardPanel {
            Text("ПРАВА API", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("Пока нужны только права чтения Spot и Futures (активы/позиции). Не включай торговлю и вывод средств на этапе подключения. Реальные сделки останутся заблокированы до отдельной проверки.", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Text("MEXC API: https://www.mexc.com/user/openapi", color = Color.White, fontSize = 10.sp)
        }
    }
}

@Composable
private fun apiFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Gold, unfocusedBorderColor = Panel2,
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
)

@Composable
private fun SettingsScreen(mode: String, onModeChange: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Spacer(Modifier.height(8.dp))
        Header("Настройки", "Режим и ограничения")
        CardPanel {
            Text("ТОРГОВЫЙ РЕЖИМ", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Paper Trading", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Виртуальные операции", color = Muted, fontSize = 10.sp)
                }
                RadioButton(selected = mode == "PAPER", onClick = { onModeChange("PAPER") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Real Trading", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Заблокирован до проверки API и защиты ордеров", color = Muted, fontSize = 10.sp)
                }
                RadioButton(selected = mode == "REAL", onClick = { onModeChange("PAPER") })
            }
            Text("Реальный режим предусмотрен, но пока заблокирован: Futures-исполнитель ещё не проверен на аккаунте, а Spot-защита SL/TP через API не подтверждена.", color = Gold, fontSize = 10.sp)
        }
        Spacer(Modifier.height(12.dp))
        CardPanel {
            RiskLine("Стартовый Paper капитал", "10 USDT")
            RiskLine("Риск на сделку", "1% · максимум 2%")
            RiskLine("Общий открытый риск", "3%")
            RiskLine("Дневной стоп", "2%")
            RiskLine("Максимум сделок в день", "5")
            RiskLine("Futures плечо", "До 2× · Isolated")
            RiskLine("Cross Margin", "Запрещён")
            RiskLine("Вывод API", "Не используется")
        }
    }
}

@Composable
private fun CardPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(19.dp)).padding(17.dp), content = content)
}
