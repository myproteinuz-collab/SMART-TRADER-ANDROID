package com.smarttrader.app

/**
 * Hard safety policy for SMART TRADER V1.
 * This module validates simulated trade proposals only.
 * Live order execution is intentionally not implemented.
 */
data class TradeProposal(
    val symbol: String,
    val market: MarketType,
    val side: TradeSide,
    val entry: Double,
    val stopLoss: Double?,
    val takeProfit: Double?,
    val leverage: Double = 1.0,
    val isolatedMargin: Boolean = true
)

enum class MarketType { SPOT, FUTURES }
enum class TradeSide { LONG, SHORT }
enum class Decision { APPROVED_FOR_PAPER, REJECTED, UNKNOWN }
data class RiskResult(val decision: Decision, val reasons: List<String>)

object RiskPolicy {
    const val STARTING_CAPITAL_USDT = 10.0
    const val TARGET_RISK_PERCENT = 1.0
    const val MAX_RISK_PER_TRADE_PERCENT = 2.0
    const val MAX_TOTAL_OPEN_RISK_PERCENT = 3.0
    const val MAX_DAILY_LOSS_PERCENT = 2.0
    const val MIN_REWARD_RISK = 1.5
    const val RESERVE_PERCENT = 10.0
    const val MAX_ORDERS_PER_DAY = 5
    const val MAX_FUTURES_LEVERAGE = 2.0

    fun validate(proposal: TradeProposal): RiskResult {
        val issues = mutableListOf<String>()
        if (proposal.symbol.isBlank()) return RiskResult(Decision.UNKNOWN, listOf("UNKNOWN_SYMBOL"))
        if (!proposal.entry.isFinite() || proposal.entry <= 0.0)
            return RiskResult(Decision.UNKNOWN, listOf("UNKNOWN_ENTRY"))
        if (proposal.stopLoss == null || proposal.takeProfit == null)
            return RiskResult(Decision.REJECTED, listOf("STOP_LOSS_AND_TAKE_PROFIT_REQUIRED"))
        if (!proposal.stopLoss.isFinite() || !proposal.takeProfit.isFinite())
            return RiskResult(Decision.UNKNOWN, listOf("UNKNOWN_PROTECTION_PRICE"))
        if (proposal.market == MarketType.SPOT && proposal.side == TradeSide.SHORT)
            issues += "SPOT_SHORT_FORBIDDEN"
        if (proposal.market == MarketType.FUTURES && !proposal.isolatedMargin)
            issues += "CROSS_MARGIN_FORBIDDEN"
        if (proposal.market == MarketType.FUTURES && proposal.leverage > MAX_FUTURES_LEVERAGE)
            issues += "LEVERAGE_LIMIT_EXCEEDED"

        val validDirection = when(proposal.side) {
            TradeSide.LONG -> proposal.stopLoss < proposal.entry && proposal.takeProfit > proposal.entry
            TradeSide.SHORT -> proposal.stopLoss > proposal.entry && proposal.takeProfit < proposal.entry
        }
        if (!validDirection) issues += "INVALID_SL_TP_DIRECTION"
        if (issues.isNotEmpty()) return RiskResult(Decision.REJECTED, issues)

        val risk = kotlin.math.abs(proposal.entry - proposal.stopLoss!!)
        val reward = kotlin.math.abs(proposal.takeProfit!! - proposal.entry)
        if (risk <= 0.0) return RiskResult(Decision.UNKNOWN, listOf("UNKNOWN_RISK_DISTANCE"))
        val rr = reward / risk
        if (rr < MIN_REWARD_RISK) issues += "REWARD_RISK_BELOW_1_5"
        if (issues.isNotEmpty()) return RiskResult(Decision.REJECTED, issues)

        // A full portfolio/order-size risk calculation is added in the Paper Engine phase.
        return RiskResult(Decision.APPROVED_FOR_PAPER, listOf("VALIDATION_ONLY_NO_ORDER_SENT"))
    }
}
